import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.Dimension;

import org.openqa.selenium.JavascriptExecutor;

import java.util.*;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class Test_1 {
    private WebDriver driver;
    private Map<String, Object> vars;
    JavascriptExecutor js;
    @Before


    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        driver = new ChromeDriver();
        js = (JavascriptExecutor) driver;
        vars = new HashMap<String, Object>();
    }
    @After
    public void tearDown() {

    }
    @Test
    public void testloginstandarduser(){
        driver.get("https://www.saucedemo.com/");
        driver.manage().window().setSize(new Dimension(1076, 816));
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.cssSelector("*[data-test=\"login-button\"]")).click();
        driver.findElement(By.cssSelector("*[data-test=\"add-to-cart-sauce-labs-fleece-jacket\"]")).click();
        driver.findElement(By.xpath("//div[@id='shopping_cart_container']/a")).click();
        driver.findElement(By.cssSelector("*[data-test=\"checkout\"]")).click();
        driver.findElement(By.id("first-name")).sendKeys("Kris");
        driver.findElement(By.cssSelector("*[data-test=\"lastName\"]")).click();
        driver.findElement(By.id("last-name")).sendKeys("Kodra");
        driver.findElement(By.id("postal-code")).sendKeys("15555");
        driver.findElement(By.cssSelector("*[data-test=\"continue\"]")).click();
        driver.findElement(By.cssSelector("*[data-test=\"finish\"]")).click();
        assertThat(driver.findElement(By.xpath("//h2[contains(.,'Thank you for your order!')]")).getText(), is("Thank you for your order!"));
        driver.findElement(By.cssSelector("*[data-test=\"back-to-products\"]")).click();
        driver.findElement(By.cssSelector("#react-burger-menu-btn")).click();





























    }






}
